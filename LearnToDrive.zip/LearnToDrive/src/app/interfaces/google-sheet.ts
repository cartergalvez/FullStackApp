export interface GoogleSheet {
    id:number;
    questions:string;
    a1:string
    a2:string;
    a3:string;
    a4:string;
    correct:string;
}
